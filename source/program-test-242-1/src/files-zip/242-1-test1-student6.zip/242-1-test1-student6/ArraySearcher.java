public class ArraySearcher
{
	public static void main(String  [] args)
	{
		int nSearch;
		int arrayLength;
		int [] a = arrayLength;
		int n;
		int nSearch = int [] searchArray;
	
		for (int n []){
			if (n ==1){
			return n;
			}
			else{
			n= -1;
			return n;
			
	}
		}
			} 
			int [5] a = (4,4,2,3,1,5);
			int nSearch = 4;
			System.out.println(a.nSearch);
			int arrayLength = (4);
			System.out.println(a.arrayLength);
			}
						