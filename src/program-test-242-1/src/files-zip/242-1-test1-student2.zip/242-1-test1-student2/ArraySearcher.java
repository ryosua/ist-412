public class ArraySearcher
{
 public static void main(String [] args)
 {
	 int nSearch= Integer.parseInt(args[0]);
	 
	 int arrayLength= Integer.parseInt(args[1]);
	 
	 int[] a;
	 a= new int[args.length];
	 
	 System.out.println (" ";)
	 
 }
 
 public static void searchArray(int[] a)
 {
	 for (int i= 0; i < array.length; i++)
	 {
		 a[i]= Integer.parseInt(args[i]);
		 if (a[i]==)
			 a[i]--
	 }
 }
