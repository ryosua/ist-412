public class Factorial
{
 public static void main(String [] args)
 {
	 int n= Integer.parseInt(args[0]);
	 
	 for (int i= 0; i < 0; i++)
	 {
		 factorial= n*(n++)
	 }
	 
	 System.out.println("Factorial= " +factorial);
	 
 }
}

 
 
	 
 