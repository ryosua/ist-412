public class TestProgram
{
  public static void main(String [] args) 
  {
	  { 
		TestProgram program = new TestProgram();
		System.out.println("\n" + "Start Demo Test by student2");
		
		String [] arg =  new String [2];
		arg[0]= "4 4 2 3 1 5";
		arg[1]= "3 4 1 2 3 4";
	    program.main(arg);
		System.out.println("End of Demo Test" + "\n");
		} 
	}
}
	
	/* 1. Command line arguments to compile 
	setup
	javac -d C:\java\bin TestProgram.java 
	java TestProgram 4 4 2 3 1 5
	
	*/ 2. 
