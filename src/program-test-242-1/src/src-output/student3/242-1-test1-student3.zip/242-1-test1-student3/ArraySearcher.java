public class ArraySearcher{
	
	public static void main(String[] args){
	
		int nSearch = Integer.parseInt(args[0]);
		int arrayLength = Integer.parseInt(args[1]);
		int [] a = new int[arrayLength];
		int a[0] = Integer.parseInt(args[3]);
		int a[1] = Integer.parseInt(args[4]);
		int a[2] = Integer.parseInt(args[5]);
		int a[3] = Integer.parseInt(args[6]);
	
	}

	public static int SearchArray(int n, int[] a){
		for(int i = 0; i < array.length; i++){
			
		}
	}
}