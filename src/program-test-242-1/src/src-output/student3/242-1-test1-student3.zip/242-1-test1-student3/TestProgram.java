public class TestProgram{

	public static void main(String[] args){
		// ArraySearcher test 1
		
		ArraySearcher program = new ArraySearcher();
		System.out.println("\n" + "Start ArraySearcher Test 1 by student3");
		String[] arg = new String[1];
		arg[0] = "123456";
		program.main(arg);
		System.out.println("End of ArraySearcher test 1" + "\n");
		
	
	}
	{
		// ArraySearcher test 2
		ArraySearcher program = new ArraySearcher();
		System.out.println("\n" + "Start ArraySearcher test 2 by student3");
		String[] arg = new String[1];
		arg[0] = "456321";
		program.main(arg);
		System.out.println("End of ArraySearcher test 2" + "\n");
	}
	
}